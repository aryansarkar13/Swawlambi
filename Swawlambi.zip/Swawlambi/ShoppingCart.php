<html>
<head>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@600&display=swap" rel="stylesheet">
</head>
<body>

<header id="header">

  <div id="brand">
     <img id="header-img" src="logo.png" href="Home.php" href="Home.php"></img>
     <a href="Home.php" style="text-decoration:none; color:#e8270b;"><h1 style="font-family: 'Dancing Script', cursive;">Swawlambi</h1></a>
  
  </div>
  <nav id="nav-bar">
    <a class="nav-link" id="active" href="#Features">Shopping cart/ आपकी खरीदारी</a>
    <a class="nav-link" href="Profile.php">Profile/प्रोफ़ाइल</a>
  </nav>
</header>
<h1 id="cart-heading">Shopping cart/ आपकी खरीदारी</h1>
<div id="cart-products">
<div id="job-results">
    <div class="product-card">
        <img src="assets/images/product1.jpg" class="product-img"></img>
        <div class="product-content">
            <h1 class="job-name">Product Name</h1>
            <h3>Description</h3>
            <h2>Price</h2>
            <h2>Seller</h2>
            <button id="alter">+</h1></button> <button id="alter">-</h1></button>
        </div>
    </div>
</div>
<div id="job-results">
    <div class="product-card">
        <img src="assets/images/product1.jpg" class="product-img"></img>
        <div class="product-content">
            <h1 class="job-name">Product Name</h1>
            <h3>Description</h3>
            <h2>Price</h2>
            <h2>Seller</h2>
            <button id="alter">+</h1></button> <button id="alter">-</h1></button>
        </div>
    </div>
</div>
</div>
<hr></hr>
<div id="buy">
    <h1 id="total">Your Total/ कुल कीमत :1000$</h1>
    <button id="checkout"><h1>Check out/ खरीदें</h1></button>
</div>
</body>
<html>